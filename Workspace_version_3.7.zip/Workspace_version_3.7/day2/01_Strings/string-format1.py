import math

a = math.pi
b = 5
c = 'python'

line = "{} {:.2f} {}".format(c, a , b)
print(line)

line = "{:0>5}".format(b)
print(line)