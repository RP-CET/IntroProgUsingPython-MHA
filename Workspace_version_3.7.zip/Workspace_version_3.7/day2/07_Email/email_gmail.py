import smtplib
sender_email_address ="rp.python.ipp@gmail.com"
sender_email_password = "fuccwnrcfqrmeovd"
receiver_email_address = "teo_tian_guan@rp.edu.sg"
email_title_content = "Subject: Sending Email Using Python\nThis is a test mail."

print("Trying to connect to Gmail SMTP server")
smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
smtpObj.starttls()

print("Connected.  Logging in...")
smtpObj.login(sender_email_address, sender_email_password)

smtpObj.sendmail(sender_email_address, receiver_email_address, email_title_content)
print("Email sent successfully...")

smtpObj.quit()
