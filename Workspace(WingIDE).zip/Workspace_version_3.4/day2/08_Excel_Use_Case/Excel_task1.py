#1. Import the necessary libraries
import glob    #search files that matches required patterns
import pandas as pd  #analyze data

# 2. Define path to the csv data files
path = './Data/'

# 3. Create a list using glob to store file names starting with 
#     Product1 and ending with .csv
fileList = glob.glob(path + "Product1*.csv")
print (fileList)

# 4. Create empty list to store the csv file as pandas dataframes
dfList = []

# 5. Cycle through the files 
for file in fileList:
    
    #read the file and convert to pandas dataframe
    data = pd.read_csv(file, encoding='utf-8')
        
    #append to the list of dataframes
    dfList.append(data)
    
# merge the data in the csvList into a single pandas dataframe
csvMerged = pd.concat(dfList) 

# 6. Output the pandas dataframes as csv
csvMerged.to_csv(path+ './Output/Product1_Q1_data.csv', index=False)