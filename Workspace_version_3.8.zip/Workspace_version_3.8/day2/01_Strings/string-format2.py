l = "admin:$E*G$@R:/users/root:"

words = l.split(':')

print("{:<15} {} {}".format("User", ":" , words[0]))
print("{:<15} {} {}".format("Password",":" ,words[1]))
print("{:<15} {} {}".format("Homedir",":" ,words[2]))

