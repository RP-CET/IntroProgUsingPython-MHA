from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html"

hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

#new-price
new_price_element = soup.find(class_="new-price")

print("Current Price: " + new_price_element.text)


#old-price
#elements = soup.select("div.product-price:nth-child(5) > div:nth-child(2)")  #  $161.90
old_price_element = soup.find(class_="old-price")

print("\nOld Price: " + old_price_element.text)


#product > div > div > div.product-container > div.product-container-column.left > div.product-header > div.product-price > div.new-price

