
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site= "https://webscraper.io/test-sites/e-commerce/static/computers/laptops"
hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')



#elements = soup.select("div.col-sm-4:nth-child(1) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(2) > a:nth-child(1)")  #  Packard 255 G2
elements = soup.select("body > div.wrapper > div.container.test-site > div > div.col-lg-9 > div.row > div:nth-child(1) > div > div > div.caption > h4:nth-child(2) > a")  #  Packard 255 G2

print("Item: " + elements[0].text)


elements = soup.select("body > div.wrapper > div.container.test-site > div > div.col-lg-9 > div.row > div:nth-child(1) > div > div > div.caption > h4.price.float-end.card-title.pull-right") # 416.99 
print("Price: " + elements[0].text)