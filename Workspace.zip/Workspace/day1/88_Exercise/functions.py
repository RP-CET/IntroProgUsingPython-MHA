def FIX_ME:
    print ("Hello world")
    
print_hello()



def print_multiple_hello(FIX_ME):
    for i in range(FIX_ME):
        print ("Hello world")
    
    
print_multiple_hello(5)