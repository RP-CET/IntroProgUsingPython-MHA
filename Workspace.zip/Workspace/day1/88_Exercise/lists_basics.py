myList = [2, 4, 6, 8]

print ("First number in the list is: " + FIX_ME)

