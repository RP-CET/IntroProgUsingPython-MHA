import os
import shutil

file = "myfile.txt"

helloFile = open(file, "w")
helloFile.write("Programming is fun!\n")
helloFile.close()


newdir = "myfolder"
if os.path.isdir(newdir):
	os.rmdir(newdir)# delete myfolder directory
else:
	os.mkdir(newdir)# create myfolder directory
 
# copy myfile.txt to myfolder
shutil.copy(file, newdir)

print("Completed")