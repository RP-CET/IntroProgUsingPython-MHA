l = "admin:$E*G$@R:/users/root:"

words = l.split(':')

print("%-15s: %s"%("User",words[0]))
print("%-15s: %s"%("Password",words[1]))
print("%-15s: %s"%("Homedir",words[2]))
