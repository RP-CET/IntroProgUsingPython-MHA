import os
from PIL import Image, ImageFilter, ImageOps

filename = "FIX_ME"

im = Image.open(filename)

out = im.transpose(FIX_ME)

im.show()
out.show()
im.save("rotated_image.jpg")