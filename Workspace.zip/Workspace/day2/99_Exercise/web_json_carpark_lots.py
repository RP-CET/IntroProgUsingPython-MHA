# hdb carpark info
# https://data.gov.sg/dataset/hdb-carpark-information

import json
import requests

url="https://api.data.gov.sg/v1/transport/carpark-availability"
req=requests.get(url)

data = json.loads(req.text)

# print update timestamp
update_time = data["items"][0]["timestamp"]
print("Update time: " + update_time)

# carpark number
carpark_number = data["items"][0]["carpark_data"][1940]["carpark_number"]
carpark_lots = data["items"][0]["carpark_data"][1940]["carpark_info"][0]["lots_available"]

print(carpark_number, "-->",carpark_lots)
''' 
===========================
Car parks at Changi Village 
===========================
''' 
carpark_info = {} #To store the carpark number & lots in a Dictionary.

i = 0
for carpark in data["items"][0]["carpark_data"]:
	carpark_info[carpark["carpark_number"] ]= [i, carpark["carpark_info"][0]["lots_available"]]
	i = i + 1

print(carpark_info["CV1"])
print(carpark_info["CV2"])
print(carpark_info["CV3"])
#print(carpark_info["CV4"]) #Data for CV4 is not available


'''
i = 0
while i < len(data["items"][0]["carpark_data"]):
	carpark_number = data["items"][0]["carpark_data"][i]["carpark_number"]
	carpark_lots = data["items"][0]["carpark_data"][i]["carpark_info"][0]["lots_available"]
	carpark_info[carpark_number]=[i, carpark_lots]

	i = i + 1
'''


'''
helloFile = open("changivillage_carparks.txt", "a")
helloFile.write("CV1: " + str(carpark_info["CV1"]) + "\n")
helloFile.write("CV2: " + str(carpark_info["CV2"]) + "\n")
helloFile.write("CV3: " + str(carpark_info["CV3"]) + "\n\n\n")

helloFile.close()

'''

