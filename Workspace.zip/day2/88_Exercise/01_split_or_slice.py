#
#extract the digits from a Singapore NRIC number
#

nric = "S6554321A"

#split (assume NRIC always starts with S and ends with A)
nric_no_prefix = nric.split("S")[0]
nric_no_prefix_and_postfix = nric_no_prefix.split("A")[FIX_ME]
print (nric_no_prefix_and_postfix)

#slice (more versatile to remove prefix/postfix as the length is fixed)
nric = "S6554321A"
nric_no_prefix_and_postfix = nric[1:-1]
print (nric_no_prefix_and_postfix)


#------------------------------------------------------
#
#extract the user_id from an email address
#
email = "jason_lim@rp.edu.sg"

#split (email address always has a @ sign)
user_id = email.split(FIX_ME)[0]
print (user_id)

#slice (assume length is fixed)
user_id = email[FIX_ME]
print (user_id)